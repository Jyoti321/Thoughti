package com.thoughti.machine.thoughtiTest.service;

import org.springframework.data.jpa.repository.JpaRepository;

import com.thoughti.machine.thoughtiTest.model.Order;

public interface OrderRepository extends JpaRepository<Order, Integer>{

}
