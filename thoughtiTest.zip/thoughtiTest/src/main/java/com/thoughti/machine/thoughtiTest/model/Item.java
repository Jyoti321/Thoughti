package com.thoughti.machine.thoughtiTest.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import lombok.Data;

@Entity
@Data
public class Item {
	
	@Id
	private int itemId;
	
	@ManyToOne
	private Order order;
	private String itemName;
	private double itemUnitPrice;
	private int itemQuantity;
	

}
