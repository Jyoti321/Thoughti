package com.thoughti.machine.thoughtiTest.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import lombok.Data;

@Entity
@Data
public class Order {
	
	@Id
	private int orderId;
	private Date orderDate;
	private String orderStatus;
	
	@OneToMany(mappedBy="order")
	private List<Item> items = new ArrayList<Item>();

}
