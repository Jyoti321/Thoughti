package com.thoughti.machine.thoughtiTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThoughtiTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
