package com.thoughti.machine.thoughtiTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThoughtiTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThoughtiTestApplication.class, args);
	}

}
